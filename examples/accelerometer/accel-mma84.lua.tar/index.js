

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local util, EventEmitter, queue, I2C__ADDRESS, OUT__X__MSB, XYZ__DATA__CFG, WHO__AM__I, CTRL__REG1, CTRL__REG4, Accelerometer, use = util, EventEmitter, queue, I2C__ADDRESS, OUT__X__MSB, XYZ__DATA__CFG, WHO__AM__I, CTRL__REG1, CTRL__REG4, Accelerometer, use;
Accelerometer = (function () local Accelerometer = nil; Accelerometer = function (this, hardware, callback)
local self = self;
--[[1041]] self = this; 
--[[1079]] self.queue = _new(queue);
--[[1128]] self.hardware = hardware;
--[[1217]] self.outputRate = (12.5);
--[[1317]] self.scaleRange = (2);
--[[1384]] self.dataInterrupt = self.hardware.digital[(1)];
--[[1501]] self.i2c = hardware:I2C(I2C__ADDRESS);
--[[1590]] self.queue:place(((function () local one = nil; one = function (this)
--[[1628]] (function () local _b = self; local _f = _b["_getChipID"]; return _f(_b, ((function () local IDRead = nil; IDRead = function (this, err, c)
--[[1676]] if err then
--[[1695]] err = _new(Error, ((("Could not connect to MMA8452Q. No reponse on I2C lines. Error: "))+(err)));
--[[1791]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err); end)(); end
end;
--[[1873]] if ((c)~=((42))) then
--[[1933]] err = _new(Error, ((((("Could not connect to MMA8452Q, received "))+(c:toString())))+((". Expected 0x2A."))));
--[[2063]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err); end)(); end
end;
--[[2152]] self:setScaleRange(self.scaleRange, (function (this, err)
--[[2212]] if err then
--[[2233]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err, callback); end)(); end
else
--[[2356]] self:setOutputRate(self.outputRate, (function (this, err)
--[[2420]] if err then
--[[2445]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err, callback); end)(); end
else
--[[2573]] setImmediate(_global, ((function () local emitReady = nil; emitReady = function (this)
--[[2625]] self:emit(("ready"));
--[[2661]] self.queue:next();
end; emitReady:__defineGetter__("name", function () return "emitReady"; end); return emitReady; end)()));
--[[2759]] if callback then
callback(_global, (null), self);
end;
--[[2810]] if true then return ; end
end;
end));
end;
end));
--[[2925]] self.dataInterrupt:once(("low"), self["_dataReady"]:bind(self));
end; IDRead:__defineGetter__("name", function () return "IDRead"; end); return IDRead; end)())); end)();
end; one:__defineGetter__("name", function () return "one"; end); return one; end)()));
--[[3002]] self:on(("newListener"), (function (this, event)
--[[3087]] if ((((event)==(("data"))))or(((event)==(("sample"))))) then
--[[3201]] self:enableDataInterrupts((true), queueNext);
end;
end));
--[[3260]] self:on(("removeListener"), (function (this, event)
--[[3362]] if ((((event)==(("data"))))or(((event)==(("sample"))))) then
--[[3440]] self:enableDataInterrupts((false), queueNext);
end;
end));
--[[3500]] self.queue:next();
end; Accelerometer:__defineGetter__("name", function () return "Accelerometer"; end); return Accelerometer; end)();

use = (function () local use = nil; use = function (this, hardware, callback)
--[[12588]] if true then return _new(Accelerometer, hardware, callback); end
end; use:__defineGetter__("name", function () return "use"; end); return use; end)();
--[[421]] util = require(_global, ("util")); 
--[[449]] EventEmitter = require(_global, ("events")).EventEmitter; 
--[[500]] queue = require(_global, ("sync-queue")); 
--[[639]] I2C__ADDRESS = (29); 
--[[880]] OUT__X__MSB = (1); 
--[[902]] XYZ__DATA__CFG = (14); 
--[[927]] WHO__AM__I = (13); 
--[[948]] CTRL__REG1 = (42); 
--[[970]] CTRL__REG4 = (45); 
--[[993]] 
--[[3522]] util:inherits(Accelerometer, EventEmitter);
--[[3567]] Accelerometer.prototype["_changeRegister"] = (function (this, change, callback)
local self = self;
--[[3640]] self = this; 
--[[3700]] (function () local _b = self; local _f = _b["_modeStandby"]; return _f(_b, ((function () local inStandby = nil; inStandby = function (this, err)
--[[3748]] if err then
--[[3765]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err, callback); end)(); end
else
--[[3875]] change(_global, ((function () local setActive = nil; setActive = function (this, err)
--[[3917]] if err then
--[[3938]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err, callback); end)(); end
else
--[[4073]] (function () local _b = self; local _f = _b["_modeActive"]; return _f(_b, callback); end)();
end;
end; setActive:__defineGetter__("name", function () return "setActive"; end); return setActive; end)()));
end;
end; inStandby:__defineGetter__("name", function () return "inStandby"; end); return inStandby; end)())); end)();
end);
--[[4137]] Accelerometer.prototype["_dataReady"] = (function (this)
local self = self;
--[[4189]] self = this; 
--[[4244]] self:getAcceleration((function (this, err, xyz)
--[[4325]] if err then
--[[4366]] self:emit(("error"), err);
else
--[[4466]] self:emit(("data"), xyz);
--[[4521]] self:emit(("sample"), xyz);
end;
--[[4559]] self.dataInterrupt:once(("low"), self["_dataReady"]:bind(self));
end));
end);
--[[4629]] Accelerometer.prototype["_failProcedure"] = (function (this, err, callback)
local self = self;
--[[4698]] self = this; 
--[[4738]] setImmediate(_global, ((function () local emitErr = nil; emitErr = function (this)
--[[4776]] self:emit(("error"), err);
end; emitErr:__defineGetter__("name", function () return "emitErr"; end); return emitErr; end)()));
--[[4832]] if callback then
callback(_global, err);
end;
--[[4864]] if true then return ; end
end);
--[[4902]] Accelerometer.prototype["_getChipID"] = (function (this, callback)
--[[4962]] (function () local _b = this; local _f = _b["_readRegister"]; return _f(_b, WHO__AM__I, (function (this, err, c)
--[[5015]] if callback then
callback(_global, err, c);
end;
end)); end)();
end);
--[[5057]] Accelerometer.prototype["_getClosestOutputRate"] = (function (this, requestedRate, callback)
local available, i = available, i;
--[[5203]] if ((requestedRate)<((0))) then
requestedRate = (0);
end;
--[[5323]] if ((requestedRate)==((0))) then
--[[5355]] if callback then
callback(_global, (null), (0));
end;
--[[5393]] if true then return ; end
end;
--[[5437]] available = this:availableOutputRates(); 
--[[5510]] i = (0); 
while ((i)<(available.length)) do 

--[[5634]] if ((available[i])<=(requestedRate)) then
--[[5706]] if callback then
callback(_global, (null), available[i]);
end;
--[[5756]] if true then return ; end
end;

local _r = i; i = _r + 1;
end;
--[[5855]] if callback then
callback(_global, (null), available[((available.length)-((1)))]);
end;
end);
--[[5996]] Accelerometer.prototype["_modeActive"] = (function (this, callback)
local self = self;
--[[6058]] self = this; 
--[[6120]] (function () local _b = self; local _f = _b["_readRegister"]; return _f(_b, CTRL__REG1, (function (this, err, c)
--[[6174]] if err then
--[[6191]] if true then return __failProcedure(_global, err); end
else
--[[6242]] if true then return (function () local _b = self; local _f = _b["_writeRegister"]; return _f(_b, CTRL__REG1, _bit.bor(_G.tointegervalue(c),_G.tointegervalue((1))), callback); end)(); end
end;
end)); end)();
end);
--[[6411]] Accelerometer.prototype["_modeStandby"] = (function (this, callback)
local self = self;
--[[6474]] self = this; 
--[[6538]] (function () local _b = self; local _f = _b["_readRegister"]; return _f(_b, CTRL__REG1, (function (this, err, c)
--[[6592]] if err then
--[[6609]] if true then return (function () local _b = self; local _f = _b["_failProcedure"]; return _f(_b, err, callback); end)(); end
else
--[[6675]] if true then return (function () local _b = self; local _f = _b["_writeRegister"]; return _f(_b, CTRL__REG1, _bit.band(_G.tointegervalue(c),_G.tointegervalue((_bit.bnot((1))))), callback); end)(); end
end;
end)); end)();
end);
--[[6753]] Accelerometer.prototype["_readRegister"] = (function (this, addressToRead, callback)
--[[6832]] (function () local _b = this; local _f = _b["_readRegisters"]; return _f(_b, addressToRead, (1), (function (this, err, regs)
--[[6897]] callback(_global, err, ((regs)and(regs[(0)])));
end)); end)();
end);
--[[6939]] Accelerometer.prototype["_readRegisters"] = (function (this, addressToRead, bytesToRead, callback)
--[[7032]] this.i2c:transfer(_new(Buffer, _arr({[0]=addressToRead}, 1)), bytesToRead, callback);
end);
--[[7147]] Accelerometer.prototype["_writeRegister"] = (function (this, addressToWrite, dataToWrite, callback)
--[[7241]] this.i2c:send(_new(Buffer, _arr({[0]=addressToWrite, dataToWrite}, 2)), callback);
end);
--[[7418]] Accelerometer.prototype["_unsafeSetScaleRange"] = (function (this, scaleRange, callback)
local self, fsr = self, fsr;
--[[7500]] self = this; 
--[[7520]] fsr = scaleRange; 
--[[7544]] if ((fsr)>((8))) then
fsr = (8);
end;
--[[7587]] fsr = _bit.arshift(_G.tointegervalue(fsr), _G.tointegervalue((2)));
--[[7694]] (function () local _b = self; local _f = _b["_changeRegister"]; return _f(_b, ((function () local change = nil; change = function (this, complete)
--[[7747]] if err then
--[[7764]] if true then return complete(_global, err); end
else
--[[7856]] (function () local _b = self; local _f = _b["_writeRegister"]; return _f(_b, XYZ__DATA__CFG, fsr, ((function () local wroteReg = nil; wroteReg = function (this, err)
--[[7928]] self.scaleRange = scaleRange;
--[[7966]] if true then return complete(_global, err); end
end; wroteReg:__defineGetter__("name", function () return "wroteReg"; end); return wroteReg; end)())); end)();
end;
end; change:__defineGetter__("name", function () return "change"; end); return change; end)()), ((function () local scaleSet = nil; scaleSet = function (this, err)
--[[8038]] if callback then
--[[8060]] callback(_global, err);
end;
--[[8085]] setImmediate(_global, self.queue.next);
end; scaleSet:__defineGetter__("name", function () return "scaleSet"; end); return scaleSet; end)())); end)();
end);
--[[8175]] Accelerometer.prototype["_unsafeSetOutputRate"] = (function (this, hz, callback)
local self = self;
--[[8250]] self = this; 
--[[8298]] (function () local _b = self; local _f = _b["_changeRegister"]; return _f(_b, ((function () local setRegisters = nil; setRegisters = function (this, finishChange)
--[[8416]] (function () local _b = self; local _f = _b["_getClosestOutputRate"]; return _f(_b, hz, ((function () local gotRequested = nil; gotRequested = function (this, err, closest)
local bin = bin;
--[[8491]] if err then
--[[8510]] if true then return finishChange(_global, _new(Error, ("Rate must be >= 1.56Hz"))); end
else
--[[8625]] self.outputRate = closest;
--[[8733]] bin = self:availableOutputRates():indexOf(closest); 
--[[8841]] if ((bin)~=((-((1))))) then
--[[8914]] (function () local _b = self; local _f = _b["_readRegister"]; return _f(_b, CTRL__REG1, ((function () local readComplete = nil; readComplete = function (this, err, regVal)
--[[8993]] if err then
--[[9018]] if true then return finishChange(_global, err); end
else
--[[9172]] regVal = _bit.band(_G.tointegervalue(regVal), _G.tointegervalue((199)));
--[[9260]] if ((bin)~=((0))) then
regVal = _bit.bor(_G.tointegervalue(regVal), _G.tointegervalue(_bit.lshift(_G.tointegervalue(bin),_G.tointegervalue((3)))));
end;
--[[9371]] (function () local _b = self; local _f = _b["_writeRegister"]; return _f(_b, CTRL__REG1, regVal, finishChange); end)();
end;
end; readComplete:__defineGetter__("name", function () return "readComplete"; end); return readComplete; end)())); end)();
else
--[[9488]] if true then return finishChange(_global, _new(Error, ("Invalid output rate."))); end
end;
end;
end; gotRequested:__defineGetter__("name", function () return "gotRequested"; end); return gotRequested; end)())); end)();
end; setRegisters:__defineGetter__("name", function () return "setRegisters"; end); return setRegisters; end)()), ((function () local rateSet = nil; rateSet = function (this, err)
--[[9604]] if callback then
--[[9626]] callback(_global, err);
end;
--[[9651]] setImmediate(_global, self.queue.next);
end; rateSet:__defineGetter__("name", function () return "rateSet"; end); return rateSet; end)())); end)();
end);
--[[9737]] Accelerometer.prototype.availableOutputRates = (function (this)
--[[9799]] if true then return _arr({[0]=(800), (400), (200), (100), (50), (12.5), (6.25), (1.56)}, 8); end
end);
--[[9914]] Accelerometer.prototype.availableScaleRanges = (function (this)
--[[10038]] if true then return _arr({[0]=(2), (4), (8)}, 3); end
end);
--[[10156]] Accelerometer.prototype.enableDataInterrupts = (function (this, enable, callback)
local self = self;
--[[10234]] self = this; 
--[[10285]] if ((this["_dataInterrupts"])==((not ((not (enable)))))) then
--[[10329]] if true then return ((callback)and(callback(_global))); end
end;
--[[10366]] this["_dataInterrupts"] = (not ((not (enable))));
--[[10402]] self.queue:place(((function () local queueEnable = nil; queueEnable = function (this)
--[[10488]] (function () local _b = self; local _f = _b["_changeRegister"]; return _f(_b, ((function () local change = nil; change = function (this, complete)
--[[10576]] (function () local _b = self; local _f = _b["_readRegister"]; return _f(_b, CTRL__REG4, (function (this, err, reg4)
local regVal = regVal;
--[[10636]] if err then
--[[10657]] if true then return complete(_global, err); end
else
--[[10774]] regVal = ((enable) and {(function () local _r =  _bit.bor(_G.tointegervalue(reg4), _G.tointegervalue((1))); reg4  = _r; return _r; end)()} or {(function () local _r =  _bit.band(_G.tointegervalue(reg4), _G.tointegervalue((_bit.bnot((1))))); reg4  = _r; return _r; end)()})[1]; 
--[[10871]] (function () local _b = self; local _f = _b["_writeRegister"]; return _f(_b, CTRL__REG4, regVal, (function (this, err)
--[[10938]] if true then return complete(_global, err); end
end)); end)();
end;
end)); end)();
end; change:__defineGetter__("name", function () return "change"; end); return change; end)()), ((function () local intSet = nil; intSet = function (this, err)
--[[11030]] if callback then
--[[11054]] callback(_global, err);
end;
--[[11083]] setImmediate(_global, self.queue.next);
end; intSet:__defineGetter__("name", function () return "intSet"; end); return intSet; end)())); end)();
end; queueEnable:__defineGetter__("name", function () return "queueEnable"; end); return queueEnable; end)()));
end);
--[[11201]] Accelerometer.prototype.getAcceleration = (function (this, callback)
local self = self;
--[[11267]] self = this; 
--[[11287]] self.queue:place(((function () local readAccel = nil; readAccel = function (this)
--[[11332]] (function () local _b = self; local _f = _b["_readRegisters"]; return _f(_b, OUT__X__MSB, (6), (function (this, err, rawData)
local out, i, gCount = out, i, gCount;
--[[11398]] if err then
_error(err or {})
end;
--[[11488]] out = _arr({}, 0); 
--[[11508]] i = (0); 
while ((i)<((3))) do 

--[[11547]] gCount = _bit.bor(_G.tointegervalue(_bit.lshift(_G.tointegervalue(rawData[((i)*((2)))]),_G.tointegervalue((8)))),_G.tointegervalue(rawData[((((i)*((2))))+((1)))])); 
--[[11668]] gCount = _bit.arshift(_G.tointegervalue(gCount),_G.tointegervalue((4)));
--[[11864]] if ((rawData[((i)*((2)))])>((127))) then
--[[11901]] gCount = (-((((((1))+((4095))))-(gCount))));
end;
--[[11994]] out[i] = ((gCount)/(((_bit.lshift(_G.tointegervalue((1)),_G.tointegervalue((12))))/((((2))*(self.scaleRange))))));

local _r = i; i = _r + 1;
end;
--[[12058]] callback(_global, (null), out);
--[[12086]] setImmediate(_global, self.queue.next);
end)); end)();
end; readAccel:__defineGetter__("name", function () return "readAccel"; end); return readAccel; end)()));
end);
--[[12193]] Accelerometer.prototype.setOutputRate = (function (this, hz, callback)
--[[12261]] this.queue:place(this["_unsafeSetOutputRate"]:bind(this, hz, callback));
end);
--[[12393]] Accelerometer.prototype.setScaleRange = (function (this, scaleRange, callback)
--[[12468]] this.queue:place(this["_unsafeSetScaleRange"]:bind(this, scaleRange, callback));
end);
--[[12550]] 
--[[12637]] exports.Accelerometer = Accelerometer;
--[[12676]] exports.use = use;

return _module.exports;
end 