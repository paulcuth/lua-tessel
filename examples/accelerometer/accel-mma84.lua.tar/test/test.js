

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local t, tmax, ok, tessel, accel = t, tmax, ok, tessel, accel;
ok = (function () local ok = nil; ok = function (this, a, d)
--[[56]] console:log(((a) and {((((("ok "))+((function () local _r = t; t = _r + 1; return _r; end)())))+((" -")))} or {((((("not ok "))+((function () local _r = t; t = _r + 1; return _r; end)())))+((" -")))})[1], d);
end; ok:__defineGetter__("name", function () return "ok"; end); return ok; end)();
--[[15]] t = (1);  tmax = (5); 
--[[35]] 
--[[127]] console:log(((((t)+((".."))))+(tmax)));
--[[172]] tessel = require(_global, ("tessel")); 
--[[204]] accel = require(_global, ("../")):use(tessel.port[((process.argv[(2)])or(("A")))]); 
--[[274]] accel:on(("sample"), (function (this, xyz)
--[[312]] ok(_global, Array:isArray(xyz), ("accelerometer data is array"));
--[[369]] ok(_global, ((xyz.length)==((3))), ("three samples"));
--[[409]] ok(_global, (((_typeof(xyz[(0)])))==(("number"))), ("idx 0 is number"));
--[[461]] ok(_global, (((_typeof(xyz[(1)])))==(("number"))), ("idx 1 is number"));
--[[513]] ok(_global, (((_typeof(xyz[(2)])))==(("number"))), ("idx 2 is number"));
--[[565]] process:exit((0));
end));

return _module.exports;
end 