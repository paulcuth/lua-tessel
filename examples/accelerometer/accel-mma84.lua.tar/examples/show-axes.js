

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tessel, accel, led1, led2, led3, textOut = tessel, accel, led1, led2, led3, textOut;
--[[356]] tessel = require(_global, ("tessel")); 
--[[388]] accel = require(_global, ("../")):use(tessel.port[("A")]); 
--[[507]] led1 = tessel.led[(0)]:output(); 
--[[542]] led2 = tessel.led[(1)]:output(); 
--[[577]] led3 = tessel.led[(2)]:output(); 
--[[613]] textOut = (""); 
--[[632]] accel:on(("ready"), (function (this)
--[[664]] accel:on(("data"), (function (this, xyz)
local x, y, z = x, y, z;
--[[726]] x = xyz[(0)]; 
--[[746]] y = xyz[(1)]; 
--[[766]] z = xyz[(2)]; 
--[[787]] textOut = ("");
--[[874]] if ((x)>((0))) then
--[[892]] led1:high();
--[[911]] textOut = textOut+("x: + | ");
else
--[[952]] led1:low();
--[[970]] textOut = textOut+("x: - | ");
end;
--[[1002]] if ((y)>((0))) then
--[[1020]] led2:high();
--[[1039]] textOut = textOut+("y: + | ");
else
--[[1080]] led2:low();
--[[1098]] textOut = textOut+("y: - | ");
end;
--[[1130]] if ((z)>((0))) then
--[[1148]] led3:high();
--[[1167]] textOut = textOut+("z: +");
else
--[[1205]] led3:low();
--[[1223]] textOut = textOut+("z: -");
end;
--[[1253]] console:log(textOut);
end));
end));
--[[1286]] accel:on(("error"), (function (this, err)
--[[1321]] console:log(("Error:"), err);
end));

return _module.exports;
end 