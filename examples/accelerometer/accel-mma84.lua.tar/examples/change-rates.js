

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tessel, accel = tessel, accel;
--[[371]] tessel = require(_global, ("tessel")); 
--[[403]] accel = require(_global, ("../")):use(tessel.port[("A")]); 
--[[540]] accel:on(("ready"), (function (this)
--[[605]] accel:on(("data"), (function (this, xyz)
--[[642]] console:log(("x:"), xyz[(0)]:toFixed((2)), ("y:"), xyz[(1)]:toFixed((2)), ("z:"), xyz[(2)]:toFixed((2)));
end));
--[[811]] setTimeout(_global, (function (this)
--[[840]] console:log(("Changing the output rate..."));
--[[888]] accel:removeAllListeners(("data"));
--[[968]] accel:setOutputRate((1.56), ((function () local rateSet = nil; rateSet = function (this)
--[[1021]] accel:on(("data"), (function (this, xyz)
--[[1063]] console:log(("slower x:"), xyz[(0)]:toFixed((2)), ("slower y:"), xyz[(1)]:toFixed((2)), ("slower z:"), xyz[(2)]:toFixed((2)));
end));
end; rateSet:__defineGetter__("name", function () return "rateSet"; end); return rateSet; end)()));
end), (2000));
end));
--[[1223]] accel:on(("error"), (function (this, err)
--[[1258]] console:log(("Error:"), err);
end));

return _module.exports;
end 