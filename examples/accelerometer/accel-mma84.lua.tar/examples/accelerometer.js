

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tessel, accel = tessel, accel;
--[[291]] tessel = require(_global, ("tessel")); 
--[[323]] accel = require(_global, ("../")):use(tessel.port[("A")]); 
--[[460]] accel:on(("ready"), (function (this)
--[[527]] accel:on(("data"), (function (this, xyz)
--[[565]] console:log(("x:"), xyz[(0)]:toFixed((2)), ("y:"), xyz[(1)]:toFixed((2)), ("z:"), xyz[(2)]:toFixed((2)));
end));
end));
--[[677]] accel:on(("error"), (function (this, err)
--[[712]] console:log(("Error:"), err);
end));

return _module.exports;
end 